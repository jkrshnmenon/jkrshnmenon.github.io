#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

char *alloc_chunk(unsigned int size)
{
    char *new_chunk = (char *)malloc(size);
    return new_chunk;
}

void print_menu()
{
    printf("\n");
    printf("Please pick one of the options\n");
    printf("1. Allocate a chunk\n");
    printf("2. Free a chunk\n");
    printf("3. View a chunk\n");
    printf("4. Exit\n");
    printf("\n");
    printf("Enter your choice: ");
}

int main()
{
    setvbuf(stdin, NULL, _IONBF, NULL);
    setvbuf(stdout, NULL, _IONBF, NULL);
    setvbuf(stderr, NULL, _IONBF, NULL);
    char *chunks[32];
    int chunk_count = 0;
    int chunk_idx;
    unsigned int choice;
    unsigned int chunk_size;
    unsigned int read_size;
    uint64_t write_location;
    memset(chunks, 0, sizeof(size_t) * 32);
    printf("Welcome to the distillary!\n");
    printf("_free_hook, _malloc_hook, etc.. have been KILLED 😱\n");
    printf("With these roadblocks in place you might have to take a detour...\n");
    printf("\n\n");
    while (true)
    {
        print_menu();
        scanf("%u", &choice);
        switch (choice)
        {
        case 1:
            if (chunk_count >= 32)
            {
                printf("TOO MANY CHUNKS!!!\n");
                break;
            }
            printf("Chunk index: ");
            scanf("%d", &chunk_idx);
            if (chunk_idx >= 32 || chunk_idx < 0)
            {
                printf("Nice try hooligan!\n");
                break;
            }
            printf("Chunk Size: ");
            scanf("%u", &chunk_size);
            chunks[chunk_idx] = alloc_chunk(chunk_size);
            chunk_count++;

            printf("Data: ");
            read(0, chunks[chunk_idx], chunk_size - 1);
            break;

        case 2:
            if (chunk_count <= 0)
            {
                printf("too few chunks~~~\n");
                break;
            }
            printf("Chunk index: ");
            scanf("%d", &chunk_idx);
            if (chunk_idx >= 32 || chunk_idx < 0)
            {
                printf("Nice try hooligan!\n");
                break;
            }
            // I'm not checking for zero if you wanna crash it, go for it...
            free(chunks[chunk_idx]);
            chunk_count--;
            break;

        case 3:
            // I'll be nice and give you a read here
            printf("Chunk index: ");
            scanf("%d", &chunk_idx);
            if (chunk_idx >= 32 || chunk_idx < 0)
            {
                printf("We've already been over this... it's time to stop...\n");
                break;
            }
            printf("Read size: ");
            scanf("%u", &read_size);
            write(1, chunks[chunk_idx], read_size);
            break;

        case 5: // shhhhhhh
            printf("Chunk index: ");
            scanf("%d", &chunk_idx);
            if (chunk_idx >= 32 || chunk_idx < 0)
            {
                printf("I don't even know what to say...\n");
                break;
            }
            printf("Read Size: ");
            scanf("%u", &read_size);
            printf("Data: ");
            read(0, chunks[chunk_idx], read_size);
            break;

        case 6:
            printf("Write Location: ");
            scanf("%" SCNu64, &write_location);
            fflush(stdin);
            fflush(stdout);

            printf("Write Location: %p\n", write_location);
            printf("Read size: ");
            scanf("%d", &read_size);
            printf("Data: ");
            read(0, (char *)write_location, read_size);
            break;

        default:
            return 1;
        }
    }
    return 0;
}






























































































































































































































// Hint!! https://codebrowser.dev/glibc/glibc/stdlib/cxa_thread_atexit_impl.c.html#148
