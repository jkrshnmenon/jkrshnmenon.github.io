#include <linux/fs.h>
#include <linux/file.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/uaccess.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ptr-yudai");
MODULE_DESCRIPTION("A vulnerable driver for a CTF");

#define CMD_READ    0x1337
#define CMD_WRITE   0x1338

typedef struct {
  int fd;
  long val;
} req_t;

static DEFINE_MUTEX(module_lock);

static long module_ioctl(struct file *filp, unsigned int cmd, unsigned long arg) {
  req_t req;
  struct file *target = NULL;
  long ret = 0;

  if (cmd != CMD_READ && cmd != CMD_WRITE) {
    return -EINVAL;
  }

  if (copy_from_user(&req, (req_t __user *)arg, sizeof(req))) {
    return -EFAULT;
  }

  mutex_lock(&module_lock);

  if (!(target = fget(req.fd))) {
    ret = -EBADF;
    goto unlock_on_fail;
  }

  if (!S_ISREG(file_inode(target)->i_mode)) {
    ret = -EBADF;
    goto unlock_on_fail;
  }

  if (cmd == CMD_READ) {
    req.val = (long)target->private_data;
    if (copy_to_user((req_t __user *)arg, &req, sizeof(req))) {
      ret = -EFAULT;
      goto unlock_on_fail;
    }
  } else {
    target->private_data = (void*)req.val;
  }

 unlock_on_fail:
  if (target) {
    fput(target);
  }

  mutex_unlock(&module_lock);
  return ret;
}

static struct file_operations module_fops = {
  .owner          = THIS_MODULE,
  .unlocked_ioctl = module_ioctl,
};
 
static struct miscdevice vuln_dev = {
  .minor = MISC_DYNAMIC_MINOR,
  .name = "vuln",
  .fops = &module_fops
};

static int __init module_initialize(void) {
  if (misc_register(&vuln_dev) != 0)
    return -EBUSY;
  return 0;
}

static void __exit module_cleanup(void) {
  misc_deregister(&vuln_dev);
  mutex_destroy(&module_lock);
}

module_init(module_initialize);
module_exit(module_cleanup);
