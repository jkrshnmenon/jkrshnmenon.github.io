import sys
import matplotlib.pyplot as plt

from pathlib import Path
from subprocess import run, CalledProcessError, PIPE


CUR_DIR = Path(__file__).parent.resolve()
C_SOURCE = CUR_DIR / 'runner.c'
C_BINARY = CUR_DIR / 'runner'


def compile_source() -> bool:
    try:
        result = run(['gcc', '-o', str(C_BINARY), str(C_SOURCE)],
                     stdout=PIPE, stderr=PIPE, text=True, check=True)
    except CalledProcessError as e:
        print("Compilation failed:")
        print(e.stderr)
        sys.exit(1)
    return True


def run_one_trial() -> int | None:
    try:
        result = run([str(C_BINARY)], stdout=PIPE, stderr=PIPE, text=True, check=True)
        return int(result.stdout.strip(), 16)
    except CalledProcessError as e:
        print("Execution failed:")
        print(e.stderr)
    except ValueError:
        print("Invalid output from binary.")
    return None


def bit_statistics(int_list) -> list[dict[str, int]]:
    bit_counts = [{'bit': i, 'zeros': 0, 'ones': 0} for i in range(32)]

    for n in int_list:
        for i in range(32):
            if (n >> i) & 1:
                bit_counts[i]['ones'] += 1
            else:
                bit_counts[i]['zeros'] += 1

    return bit_counts


def plot_bit_probabilities(bit_stats, title="Bit Probabilities (0..31)", style="stacked", show=True):
    # Ensure sorted by bit index (0..31)
    stats = sorted(bit_stats, key=lambda d: d['bit'])
    bits   = [d['bit']  for d in stats]
    zeros  = [d['zeros'] for d in stats]
    ones   = [d['ones']  for d in stats]
    totals = [z + o for z, o in zip(zeros, ones)]

    # Avoid division by zero (if a bit had no observations, assign 0 probability to both)
    prob1 = [(o / t) if t else 0.0 for o, t in zip(ones, totals)]
    prob0 = [1.0 - p for p in prob1]

    fig, ax = plt.subplots(figsize=(12, 4))

    if style == "grouped":
        width = 0.45
        x = range(len(bits))
        ax.bar([i - width/2 for i in x], prob0, width=width, label="P(bit=0)")
        ax.bar([i + width/2 for i in x], prob1, width=width, label="P(bit=1)")
    else:  # stacked
        ax.bar(bits, prob0, label="P(bit=0)")
        ax.bar(bits, prob1, bottom=prob0, label="P(bit=1)")

    ax.set_title(title)
    ax.set_xlabel("Bit position")
    ax.set_ylabel("Probability")
    ax.set_xticks(bits)
    ax.set_ylim(0.0, 1.0)
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.legend(loc="upper right")
    fig.tight_layout()

    if show:
        plt.show()

    return fig, ax


def run_experiment(num_trials: int):
    assert C_BINARY.exists(), "Compiled binary does not exist."

    results = []
    for x in range(num_trials):
        result = run_one_trial()
        if result is not None:
            results.append(result)
        else:
            print(f"Trial {x + 1} failed.")


    stats = bit_statistics(results)
    print(f"Bit statistics after {num_trials} trials:")
    for b in stats:
        print(f"Bit {b['bit']:2d}: 0s={b['zeros']:3d}, 1s={b['ones']:3d}")

    plot_bit_probabilities(stats, title=f"Bit Probabilities after {num_trials} Trials", style="stacked")


if __name__ == '__main__':
    num_trials = 100 if len(sys.argv) < 2 else int(sys.argv[1])
    assert num_trials > 0, "Number of trials must be positive."
    assert compile_source()

    run_experiment(num_trials)
