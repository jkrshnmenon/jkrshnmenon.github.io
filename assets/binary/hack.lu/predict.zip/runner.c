#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>

uint64_t find_mapping_start(uint64_t addr) {
    FILE *maps = fopen("/proc/self/maps", "r");
    if (!maps) {
        perror("fopen");
        return -1;
    }

    char line[256];
    while (fgets(line, sizeof(line), maps)) {
        uint64_t start, end;
        if (sscanf(line, "%lx-%lx", &start, &end) == 2) {
            if (addr >= start && addr < end) {
                fclose(maps);
                // printf("Found mapping: %s\n", line);
                return start;
            }
        }
    }

    fclose(maps);
    return -1;
}

void* thread_func(void* arg) {
    char buf[0x100];
    char *p = malloc(0x100);
    if (!p) {
        perror("malloc");
        return NULL;
    }
    uint64_t stack_start = find_mapping_start((uint64_t)&buf);
    uint64_t heap_start = find_mapping_start((uint64_t)p);
    // printf("Stack mapping starts at: 0x%lx\n", stack_start);
    // printf("Heap mapping starts at: 0x%lx\n", heap_start);
    printf("%#lx\n", stack_start - heap_start);
    free(p);
    return NULL;
}

int main() {
    pthread_t thread;
    const char* msg = "Running in parallel!";
    
    // Create a new thread
    if (pthread_create(&thread, NULL, thread_func, (void*)msg) != 0) {
        perror("pthread_create");
        return 1;
    }

    // Wait for the thread to finish
    pthread_join(thread, NULL);
    return 0;
}

